﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using OfficeOpenXml;
using Telegram.Bot.Types.InputFiles;

class Program
{
    private static readonly TelegramBotClient botClient = new TelegramBotClient("7250754803:AAGiG7ym-DwdSI51xDaWYf1mQ9TsoAnq9_U");

    // Зберігаємо дані для кожного чату окремо
    private static readonly Dictionary<long, Dictionary<long, UserStats>> chatUserStats = new();
    private static readonly string excelFilePath = "user_message_data.xlsx";

    private static readonly long botOwnerId = 250945736; // Ваш Telegram ID

    static async Task Main(string[] args)
    {
        botClient.StartReceiving(HandleUpdateAsync, HandleErrorAsync);

        Console.WriteLine("Bot is running...");

        // Працює хвилинний таймер для оновлення Excel-файлу
        Timer minuteTimer = new Timer(UpdateFiles, null, TimeSpan.Zero, TimeSpan.FromMinutes(1));

        // Не завершує роботу бота, поки він активний
        await Task.Delay(-1);
    }

    private static async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
    {
        if (update.Type == UpdateType.Message && update.Message != null)
        {
            var message = update.Message;
            long chatId = message.Chat.Id;
            long userId = message.From?.Id ?? 0; // Перевірка на null, надання значення за замовчуванням
            string username = message.From?.Username ?? "Unknown"; // Перевірка на null, надання значення за замовчуванням
            string? text = message.Text;

            // Перевірка, чи вже є дані для цього чату
            if (!chatUserStats.ContainsKey(chatId))
            {
                chatUserStats[chatId] = new Dictionary<long, UserStats>();
            }

            double points = 0;
            string messageText = text ?? "N/A";

            // Обробка команд, які може виконувати лише власник бота
            if (userId == botOwnerId)
            {
                if (text?.Equals("/startbot", StringComparison.OrdinalIgnoreCase) == true)
                {
                    await botClient.SendTextMessageAsync(message.Chat.Id, "Bot has started. I am tracking message lengths.");
                    return;
                }

                if (text?.Equals("/resetbot", StringComparison.OrdinalIgnoreCase) == true)
                {
                    chatUserStats[chatId].Clear();
                    LogMessageReset(chatId); // Додано логування reset-команди
                    await botClient.SendTextMessageAsync(message.Chat.Id, "Data has been reset.");
                    return;
                }

                if (text?.Equals("/topbot", StringComparison.OrdinalIgnoreCase) == true)
                {
                    await SendCurrentTop10(message.Chat.Id);
                    return;
                }

                if (text?.Equals("/getfilebot", StringComparison.OrdinalIgnoreCase) == true)
                {
                    await SendExcelFile(message.Chat.Id);
                    return;
                }
            }

            // Перевірка типу повідомлення
            if (message.Photo != null && message.Photo.Any())
            {
                points = 10; // Нарахування 10 поінтів за зображення
                messageText = "Photo"; // Замість тексту вказуємо, що це було зображення
            }
            else if (text != null)
            {
                int messageLength = text.Length;
                points = CalculatePoints(messageLength);
            }

            // Збільшення лічильника поінтів, символів та повідомлень для користувача
            if (chatUserStats[chatId].ContainsKey(userId))
            {
                var userStats = chatUserStats[chatId][userId];
                userStats.Points += points;
                userStats.TotalCharacters += messageText.Length; // Довжина рядка буде 0 для "N/A"
                userStats.TotalMessages++;
            }
            else
            {
                chatUserStats[chatId][userId] = new UserStats
                {
                    Username = username,
                    Points = points,
                    TotalCharacters = messageText.Length, // Довжина рядка буде 0 для "N/A"
                    TotalMessages = 1,
                    DeletedMessages = 0,
                    DeletedCharacters = 0
                };
            }

            // Запис повідомлення в Excel
            LogMessage(chatId, userId, username, messageText, points);

            // Логування інформації в консолі
            Console.WriteLine($"Chat ID: {chatId}");
            Console.WriteLine($"User ID: {userId}");
            Console.WriteLine($"Username: {username}");
            Console.WriteLine($"Message Text: {messageText}");
            Console.WriteLine($"Message Length: {messageText.Length}");
            Console.WriteLine($"Points Earned: {points}");
            Console.WriteLine("----------------------------");
        }
    }

    private static double CalculatePoints(int messageLength)
    {
        if (messageLength <= 10)
        {
            return messageLength * 0.25;
        }
        else if (messageLength <= 25)
        {
            return messageLength * 0.5;
        }
        else if (messageLength <= 75)
        {
            return messageLength * 0.75;
        }
        else
        {
            return messageLength * 1.0;
        }
    }

    private static Task HandleErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
    {
        Console.WriteLine(exception.ToString());
        return Task.CompletedTask;
    }

    private static async Task SendCurrentTop10(long chatId)
    {
        string message = GetTop10Message(chatId);
        await botClient.SendTextMessageAsync(chatId, message);
    }

    private static string GetTop10Message(long chatId)
    {
        if (!chatUserStats[chatId].Any())
        {
            return "No data available yet.";
        }

        var topUsers = chatUserStats[chatId]
            .OrderByDescending(pair => pair.Value.Points)
            .Take(10)
            .Select((pair, index) => $"{index + 1}. {pair.Value.Username}: {pair.Value.Points} points");

        return "Current Top 10 users:\n" + string.Join("\n", topUsers);
    }

    private static void UpdateFiles(object? state)
    {
        UpdateExcelFile();
        Console.WriteLine("Excel file updated.");
    }

    private static void UpdateExcelFile()
    {
        using (var package = new ExcelPackage())
        {
            ExcelWorksheet leaderboardSheet;
            ExcelWorksheet messageSheet;

            // Якщо файл існує, відкриваємо його, інакше створюємо новий
            if (System.IO.File.Exists(excelFilePath))
            {
                var existingFile = new System.IO.FileInfo(excelFilePath);
                package.Load(existingFile.OpenRead());
                leaderboardSheet = package.Workbook.Worksheets.FirstOrDefault() ?? package.Workbook.Worksheets.Add("Leaderboard");
                messageSheet = package.Workbook.Worksheets.FirstOrDefault(ws => ws.Name == "Messages") ?? package.Workbook.Worksheets.Add("Messages");
            }
            else
            {
                leaderboardSheet = package.Workbook.Worksheets.Add("Leaderboard");
                messageSheet = package.Workbook.Worksheets.Add("Messages");
            }

            // Оновлення таблиці лідерів
            int row = 1;
            leaderboardSheet.Cells[row, 1].Value = "Chat ID";
            leaderboardSheet.Cells[row, 2].Value = "User ID";
            leaderboardSheet.Cells[row, 3].Value = "Username";
            leaderboardSheet.Cells[row, 4].Value = "Points";
            leaderboardSheet.Cells[row, 5].Value = "Total Characters";
            leaderboardSheet.Cells[row, 6].Value = "Total Messages";
            leaderboardSheet.Cells[row, 7].Value = "Deleted Messages";
            leaderboardSheet.Cells[row, 8].Value = "Deleted Characters";

            foreach (var chatEntry in chatUserStats)
            {
                long chatId = chatEntry.Key;
                foreach (var userEntry in chatEntry.Value)
                {
                    row++;
                    leaderboardSheet.Cells[row, 1].Value = chatId; // Chat ID
                    leaderboardSheet.Cells[row, 2].Value = userEntry.Key; // User ID
                    leaderboardSheet.Cells[row, 3].Value = userEntry.Value.Username; // Username
                    leaderboardSheet.Cells[row, 4].Value = userEntry.Value.Points; // Points
                    leaderboardSheet.Cells[row, 5].Value = userEntry.Value.TotalCharacters; // Total Characters
                    leaderboardSheet.Cells[row, 6].Value = userEntry.Value.TotalMessages; // Total Messages
                    leaderboardSheet.Cells[row, 7].Value = userEntry.Value.DeletedMessages; // Deleted Messages
                    leaderboardSheet.Cells[row, 8].Value = userEntry.Value.DeletedCharacters; // Deleted Characters
                }
            }

            // Зберігаємо файл
            var file = new System.IO.FileInfo(excelFilePath);
            package.SaveAs(file);
        }
    }

    private static void LogMessage(long chatId, long userId, string username, string messageText, double points)
    {
        using (var package = new ExcelPackage(new System.IO.FileInfo(excelFilePath)))
        {
            var messageSheet = package.Workbook.Worksheets.FirstOrDefault(ws => ws.Name == "Messages") ?? package.Workbook.Worksheets.Add("Messages");

            int row = messageSheet.Dimension?.Rows + 1 ?? 1;
            messageSheet.Cells[row, 1].Value = chatId;
            messageSheet.Cells[row, 2].Value = userId;
            messageSheet.Cells[row, 3].Value = username;
            messageSheet.Cells[row, 4].Value = messageText ?? "N/A"; // Додано перевірку на null
            messageSheet.Cells[row, 5].Value = DateTime.Now.ToString("g"); // Час у форматі дати та часу
            messageSheet.Cells[row, 6].Value = messageText?.Length ?? 0; // Довжина повідомлення
            messageSheet.Cells[row, 7].Value = points; // Кількість поінтів

            package.Save();
        }
    }

    private static void LogMessageReset(long chatId)
    {
        using (var package = new ExcelPackage(new System.IO.FileInfo(excelFilePath)))
        {
            var messageSheet = package.Workbook.Worksheets.FirstOrDefault(ws => ws.Name == "Messages") ?? package.Workbook.Worksheets.Add("Messages");

            int row = messageSheet.Dimension?.Rows + 1 ?? 1;
            messageSheet.Cells[row, 1].Value = chatId;
            messageSheet.Cells[row, 3].Value = "System";
            messageSheet.Cells[row, 4].Value = "Reset command issued";
            messageSheet.Cells[row, 5].Value = DateTime.Now.ToString("g"); // Час у форматі дати та часу

            package.Save();
        }
    }

    private static async Task SendExcelFile(long chatId)
    {
        if (System.IO.File.Exists(excelFilePath))
        {
            using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                var inputFile = new InputOnlineFile(stream, "user_message_data.xlsx");
                await botClient.SendDocumentAsync(chatId, inputFile);
            }
        }
        else
        {
            await botClient.SendTextMessageAsync(chatId, "Excel file not found.");
        }
    }

    // Оновлений клас UserStats
    class UserStats
    {
        public string Username { get; set; } = string.Empty; // Забезпечуємо, що Username ніколи не буде null
        public double Points { get; set; }
        public int TotalCharacters { get; set; }
        public int TotalMessages { get; set; }
        public int DeletedMessages { get; set; }
        public int DeletedCharacters { get; set; }
    }
}
