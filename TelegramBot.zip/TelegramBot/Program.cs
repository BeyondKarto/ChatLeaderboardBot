﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using OfficeOpenXml;
using Telegram.Bot.Types.InputFiles;

class Program
{
    private static readonly TelegramBotClient botClient = new TelegramBotClient("7250754803:AAGiG7ym-DwdSI51xDaWYf1mQ9TsoAnq9_U");

    // Зберігаємо дані для кожного чату окремо
    private static readonly Dictionary<long, Dictionary<long, (string Username, double Points)>> chatUserScores = new();
    private static readonly string excelFilePath = "user_message_data.xlsx";

    private static readonly long botOwnerId = 250945736; // Ваш Telegram ID

    static async Task Main(string[] args)
    {
        botClient.StartReceiving(HandleUpdateAsync, HandleErrorAsync);

        Console.WriteLine("Bot is running...");

        // Працює хвилинний таймер для оновлення Excel-файлу
        Timer minuteTimer = new Timer(UpdateFiles, null, TimeSpan.Zero, TimeSpan.FromMinutes(1));

        // Працює щотижневий таймер для відправки рейтингу
        Timer weeklyTimer = new Timer(SendWeeklyTop10, null, TimeSpan.Zero, TimeSpan.FromDays(7));

        // Не завершує роботу бота, поки він активний
        await Task.Delay(-1);
    }

    private static async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
    {
        if (update.Type == UpdateType.Message && update.Message.Text != null)
        {
            var message = update.Message;
            long chatId = message.Chat.Id;
            long userId = message.From.Id;

            // Перевірка, чи вже є дані для цього чату
            if (!chatUserScores.ContainsKey(chatId))
            {
                chatUserScores[chatId] = new Dictionary<long, (string Username, double Points)>();
            }

            string username = message.From.Username ?? "Anonymous";
            int messageLength = message.Text.Length;

            // Обробка команд, які може виконувати лише власник бота
            if (userId == botOwnerId)
            {
                if (message.Text.Equals("/start", StringComparison.OrdinalIgnoreCase))
                {
                    await botClient.SendTextMessageAsync(message.Chat.Id, "Bot has started. I am tracking message lengths.");
                    return;
                }

                if (message.Text.Equals("/reset", StringComparison.OrdinalIgnoreCase))
                {
                    chatUserScores[chatId].Clear();
                    await botClient.SendTextMessageAsync(message.Chat.Id, "Data has been reset.");
                    return;
                }

                if (message.Text.Equals("/top", StringComparison.OrdinalIgnoreCase))
                {
                    await SendCurrentTop10(message.Chat.Id);
                    return;
                }

                if (message.Text.Equals("/getfile", StringComparison.OrdinalIgnoreCase))
                {
                    await SendExcelFile(message.Chat.Id);
                    return;
                }
            }

            // Підрахунок поінтів на основі довжини повідомлення
            double points = CalculatePoints(messageLength);

            // Збільшення лічильника поінтів для користувача
            if (chatUserScores[chatId].ContainsKey(userId))
            {
                chatUserScores[chatId][userId] = (username, chatUserScores[chatId][userId].Points + points);
            }
            else
            {
                chatUserScores[chatId][userId] = (username, points);
            }

            Console.WriteLine($"User {username} sent a message with {messageLength} characters in chat {chatId}, earned {points} points.");
        }
    }

    private static double CalculatePoints(int messageLength)
    {
        if (messageLength <= 10)
        {
            return messageLength * 0.25;
        }
        else if (messageLength <= 25)
        {
            return messageLength * 0.5;
        }
        else if (messageLength <= 75)
        {
            return messageLength * 0.75;
        }
        else
        {
            return messageLength * 1.0;
        }
    }

    private static Task HandleErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
    {
        Console.WriteLine(exception.ToString());
        return Task.CompletedTask;
    }

    private static async void SendWeeklyTop10(object? state)
    {
        foreach (var chatId in chatUserScores.Keys)
        {
            string message = GetTop10Message(chatId);
            await botClient.SendTextMessageAsync(chatId, message);

            // Скидання лічильників
            chatUserScores[chatId].Clear();
        }
    }

    private static async Task SendCurrentTop10(long chatId)
    {
        string message = GetTop10Message(chatId);
        await botClient.SendTextMessageAsync(chatId, message);
    }

    private static string GetTop10Message(long chatId)
    {
        if (!chatUserScores[chatId].Any())
        {
            return "No data available yet.";
        }

        var topUsers = chatUserScores[chatId]
            .OrderByDescending(pair => pair.Value.Points)
            .Take(10)
            .Select((pair, index) => $"{index + 1}. {pair.Value.Username}: {pair.Value.Points} points");

        return "Current Top 10 users:\n" + string.Join("\n", topUsers);
    }

    private static void UpdateFiles(object? state)
    {
        UpdateExcelFile();
        Console.WriteLine("Excel file updated.");
    }

    private static void UpdateExcelFile()
    {
        using (var package = new ExcelPackage())
        {
            ExcelWorksheet worksheet;

            // Якщо файл існує, відкриваємо його, інакше створюємо новий
            if (System.IO.File.Exists(excelFilePath))
            {
                var existingFile = new System.IO.FileInfo(excelFilePath);
                package.Load(existingFile.OpenRead());
                worksheet = package.Workbook.Worksheets.FirstOrDefault() ?? package.Workbook.Worksheets.Add("User Message Data");
            }
            else
            {
                worksheet = package.Workbook.Worksheets.Add("User Message Data");
            }

            int row = 1;
            worksheet.Cells[row, 1].Value = "Chat ID";
            worksheet.Cells[row, 2].Value = "User ID";
            worksheet.Cells[row, 3].Value = "Username";
            worksheet.Cells[row, 4].Value = "Points";

            foreach (var chatEntry in chatUserScores)
            {
                long chatId = chatEntry.Key;
                foreach (var userEntry in chatEntry.Value)
                {
                    row++;
                    worksheet.Cells[row, 1].Value = chatId; // Chat ID
                    worksheet.Cells[row, 2].Value = userEntry.Key; // User ID
                    worksheet.Cells[row, 3].Value = userEntry.Value.Username; // Username
                    worksheet.Cells[row, 4].Value = userEntry.Value.Points; // Points
                }
            }

            // Зберігаємо файл
            var file = new System.IO.FileInfo(excelFilePath);
            package.SaveAs(file);
        }
    }

    private static async Task SendExcelFile(long chatId)
    {
        if (System.IO.File.Exists(excelFilePath))
        {
            using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                var inputFile = new InputOnlineFile(stream, "user_message_data.xlsx");
                await botClient.SendDocumentAsync(chatId, inputFile);
            }
        }
        else
        {
            await botClient.SendTextMessageAsync(chatId, "Excel file not found.");
        }
    }
}